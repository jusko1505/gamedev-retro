using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HUDManager : MonoBehaviour {
    public TMPro.TextMeshProUGUI scoreLabel;
 // Use this for initialization
    void Start()
    {
        //Refresh();
    }
 // Show player stats in the HUD
    public void Update(){
        scoreLabel.text = "Score: " + GameManager.instance.score;
    }
}